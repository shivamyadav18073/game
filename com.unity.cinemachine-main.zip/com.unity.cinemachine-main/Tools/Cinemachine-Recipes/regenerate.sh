cd ../../
dotnet run --project Tools/CineMachine-Recipes/Cinemachine.Cookbook.csproj