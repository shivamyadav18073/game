# 2D and top-down games

Use and configure Cinemachine to meet your expectations according to specific requirements of 2D graphics and top-down games.

* [Cinemachine and 2D graphics](Cinemachine2D.md)

* [Cinemachine and top-down games](CinemachineTopDown.md)
