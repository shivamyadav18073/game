# 3D tracking scenarios

Use Cinemachine to follow and look at the active characters of your 3D games.


* [Follow and frame a character](setup-follow-camera.md)

* [Follow and frame a group](GroupingTargets.md)

* [Create a FreeLook Camera](FreeLookCameras.md)

* [Create a Third Person Camera](ThirdPersonCameras.md)
