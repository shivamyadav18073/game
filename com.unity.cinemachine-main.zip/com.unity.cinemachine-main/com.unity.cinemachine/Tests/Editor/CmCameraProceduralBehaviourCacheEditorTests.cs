using System;
using NUnit.Framework;
using UnityEngine;

namespace Unity.Cinemachine.Tests.Editor
{
    [TestFixture]
    public class CmCameraProceduralBehaviourCacheEditorTests : CmCameraProceduralBehaviourCacheTests
    {
        // this allows the parent class to run in the editor
    }
}